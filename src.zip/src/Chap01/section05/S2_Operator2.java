package Chap01.section05;
/**
 * 
 * @author user
 * 사칙 연산자: +,-,*(곱셈),/(나눗셈),%(나머지 연산)
 */
public class S2_Operator2 {
public static void main(String[] args) {
	   int a=3;
	   int b=2;
	   System.out.println(a+b);
	   System.out.println(a-b);
	   System.out.println(a*b);
	   System.out.println(a/b);
	   System.out.println(a%b);
} 
}
