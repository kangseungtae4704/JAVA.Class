package Chap01.section05;

/**
 * 
 * @author user
 * 비교연산자(부등호): >, < --(같다), !=(다르다)
 */
public class S3_Operator3 {
 public static void main(String[] args) {
	int a=3;
	int b=2;
	System.out.println(a==b);// 결과: 참(true)/거짓(false)
	System.out.println(a<b); // 거짓(false)
	System.out.println(a>b); // 참(true)
	System.out.println(a!=b); // 참(true)
}
}
