/**
 * 
 */
package Chap01.section05;

/**
 * @author user
 * 축약식(짧게 코딩하는 법): 일부가 가능 
 */
public class S5_Operator5 {
 public static void main(String[] args) {
	int a=1;
//	사용법: 변수 = 변수+ 값; => 변수+=값;(축약식)
//	      변수 = 변수-값;=>변수-=값;
//	a= a+2;
	a+=2;
	System.out.println(a);
}
}
