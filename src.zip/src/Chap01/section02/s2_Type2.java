package Chap01.section02;
/**
 * 
 * @author user
 * 실수 종류 알아보기: float , double(*)
 */
public class s2_Type2 {
    public static void main(String[] args) {
    	float a=1.5f; // 작은 실수
        double b=10.5; // 큰 실수(범위 큰: 8byte)
        
        System.out.println(a);
        System.out.println(b);
	}
    
}
