package Chap01.section02;
/**
 * 
 * @author user
 * 참/거짓 알아보기, 기타 자료형(char) 
 */
public class s3_Type3 {
public static void main(String[] args) {
	// 사용법: char 변수 ='글자';
	char a='A'; // 무조건 글자 1개만 저장
	String b="홍길동"; 
	// 사용법: boolean 변수=true(false);
	boolean c=true;
	
	System.out.println(a);
	System.out.println(b);
	System.out.println(c);
}
}
