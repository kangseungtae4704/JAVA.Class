package Chap01.section03;

public class S5_Quiz {
  public static void main(String[] args) {
	String a="3.14";
	double b=Double.parseDouble(a);
	 System.out.println(a);		
} 
}
