package Chap01.section03;

public class S2_Casting {
	//TODO: 강제 정수 변환: int 변수=(int)변수2;
    public static void main(String[] args) {
		long a=1;
    int b=(int)a;
    System.out.println(b);
 
    //TODO: 강제 실수 변환: float 변수 =(float)변수;
    double c=1.5;
    float d=(float)c;
    System.out.println(d);
}
}