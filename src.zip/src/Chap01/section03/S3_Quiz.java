package Chap01.section03;

public class S3_Quiz {
    public static void main(String[] args) {
		char a='B';
		int b=a;
		System.out.println(b);
		
		char c=(char)b;
		System.out.println(c);
	}
}