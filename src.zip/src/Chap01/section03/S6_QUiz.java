package Chap01.section03;

public class S6_QUiz {
 public static void main(String[] args) {
	System.out.printf("%d",100 );
	System.out.println();
	System.out.printf("%s","hello");
	System.out.println();
	System.out.printf("%x",11);
}
}
