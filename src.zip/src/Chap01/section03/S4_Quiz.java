package Chap01.section03;

public class S4_Quiz {
public static void main(String[] args) {
	String a="100";
	int b=Integer.parseInt(a,10);
	System.out.println(b);
	
	int c=Integer.parseInt(a,2);
	System.out.println(c);
}
}
