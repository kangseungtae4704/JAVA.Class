/**
 * 
 */
package Chap01.section01;

/**
 * @author user
 *
 */
public class s1_Quiz {
 public static void main(String[] args) {
	System.out.println("안녕하세요");
	System.out.println(2);
}
}
