package Chap01.section01;

public class s1_Type {     
	byte a=1; //정수
	int  c=100; // 정수 
}
