package Chap01.section01;

public class s2_Quiz {
	public static void main(String[] args) {
		String a="안녕하세요";
		System.out.println(a);
		int b=2;
		System.out.println(b);
	}
}
