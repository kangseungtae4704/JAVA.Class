package Chap01.section01;

public class s4_Quiz {
public static void main(String[] args) {
	int a=30;
	int b=20;
	System.out.println(a*b);
	System.out.println(a/b);
	System.out.println(a%b);
}
}
