package Chap01.section01;

public class s2_Variable {
	public static void main(String[] args) {
		String a="Hello world";
		System.out.println(a);
		
//		숫자 표시: 정수, 실수 구별함 
//		정수 표시 사용법 : int 변수명 = 값;
		int b=1;
				System.out.println(b);
	}
}
