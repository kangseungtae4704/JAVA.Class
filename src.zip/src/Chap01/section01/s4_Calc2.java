/**
 * 
 */
package Chap01.section01;

/**
 * @author user
 *
 */
public class s4_Calc2 {
public static void main(String[] args) {
	int a=3;
	int b=2;
	System.out.println(a*b);
	System.out.println(a/b);
	System.out.println(a%b);
}
}
