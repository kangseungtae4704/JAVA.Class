package Chap01.section01;

public class s6_Calc4 {
public static void main(String[] args) {
	String a="a:";
	int b=2;
    System.out.println(a+b);
}
}
