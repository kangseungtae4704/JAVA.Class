package Chap01.section01;

public class s6_Calc {
public static void main(String[] args) {
	String a="x:";
	int b=20;
	System.out.println(a+b);
}
}
