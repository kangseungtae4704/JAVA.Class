package Chap01.section01;

public class s3_Calc {
//	화면표시: sysout =>더블클릭해서복사해서 쓰면편함
    public static void main(String[] args) {
		int a=3;
		int b=2;
//		덧셈:+
		System.out.println(a+b);
		System.out.println(a-b);
	}
}
