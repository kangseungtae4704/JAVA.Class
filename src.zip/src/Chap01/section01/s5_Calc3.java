package Chap01.section01;

public class s5_Calc3 {
public static void main(String[] args) {
	String a="Hello";
	String b="world";
	System.out.println(a+b);
}
}
