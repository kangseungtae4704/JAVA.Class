package Chap01.section01;

public class s5_Quiz3 {
public static void main(String[] args) {
	String a="안녕하세요";
	String b="반갑습니다";
    System.out.println(a+b);	
}
}
