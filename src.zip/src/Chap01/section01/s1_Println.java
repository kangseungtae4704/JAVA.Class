/**
 * 
 */
package Chap01.section01;

/**
 * @author user
 *
 */
public class s1_Println {
// 주석 단축키 : crtl + / 
//	main 함수단축키 :ma입력 후 ctrl+ space(자동완성 목록)
//	main: 실행함수(한번만 코딩)
   public static void main(String[] args) {
//	화면에 글자 표시 단축키 : sysout ctrl+space
//	   함수: 편리한 도구
//	   사용법: system.out.println("글자");
	  System.out.println("Hello World");
//	  사용법: system.out.println(정수); - 정수는 ""안씀
	  System.out.println(1);
     }
}
