package Chap01.section04;

import java.util.Scanner;

public class S1_Quiz {
   public static void main(String[] args) {
}
}
