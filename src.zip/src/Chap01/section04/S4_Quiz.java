package Chap01.section04;

import java.util.Scanner;

public class S4_Quiz {
 public static void main(String[] args) {
	Scanner a= new Scanner(System.in);
			String b=a.next();
			String c=a.next();
			String d=a.next();
			String f=a.next();
}
}
