/**
 * 
 */
package Chap01.section04;

import java.util.Scanner;

/**
 * @author user
 *
 */
public class S4_Scanner4 {
 public static void main(String[] args) {
	Scanner a=new Scanner(System.in);
	String b = a.next(); //단어 1개 I
	String c = a.next(); //단어 1개 am
	System.err.println(b+""+c);
	
}
}
