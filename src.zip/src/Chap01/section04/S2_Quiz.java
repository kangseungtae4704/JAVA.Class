/**
 * 
 */
package Chap01.section04;

import java.util.Scanner;

/**
 * @author user
 *
 */
public class S2_Quiz {
  public static void main(String[] args) {
    Scanner a= new Scanner(System.in);
	int b= a.nextInt();
	System.out.println(b);
}
}
