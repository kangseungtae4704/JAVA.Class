package Chap01.section04;

import java.util.Scanner;

public class S3_Scanner3 {
 public static void main(String[] args) {
	Scanner a = new Scanner(System.in);
	double b=a.nextDouble();
	System.out.println(b);
}
}
