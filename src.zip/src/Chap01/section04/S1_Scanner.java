package Chap01.section04;

import java.util.Scanner;

/**
 * 
 * @author user
 *
 */
public class S1_Scanner {
	public static void main(String[] args) {
		Scanner a=new Scanner(System.in);
		String b = a.next();
		System.out.println(b);
	}
}