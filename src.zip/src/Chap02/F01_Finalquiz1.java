package Chap02;

public class F01_Finalquiz1 {
public static void main(String[] args) {
	String a="굿모닝";
	System.out.println(a);
}
}
