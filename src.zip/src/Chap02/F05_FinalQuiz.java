package Chap02;

import java.util.Scanner;

public class F05_FinalQuiz {
	public static void main(String[] args) {
		Scanner a= new Scanner(System.in);
		String b=a.next();
		String c=a.next();
		System.out.println(b);
		System.out.println(c);
	}
	}
	
