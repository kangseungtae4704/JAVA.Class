package Chap02;

public class F02_FinalQuiz {
	public static void main(String[] args) {
	int a=5;
	double b=3.14;
	System.out.println(a*a*b);
	}
}
