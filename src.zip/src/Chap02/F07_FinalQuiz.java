package Chap02;

import java.util.Scanner;

public class F07_FinalQuiz {
 public static void main(String[] args) {
	Scanner a = new Scanner(System.in);
	int b= a.nextInt(); // 3
	int c= a.nextInt(); // 2
//	int 가 정수인데 우리가 원하는 값은 1.5
//  b/c => (double)를 삽입하여 강제 변환
	System.out.println((double)b/c);
}
}
