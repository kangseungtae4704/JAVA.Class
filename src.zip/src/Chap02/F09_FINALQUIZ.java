package Chap02;

import java.util.Scanner;

public class F09_FINALQUIZ {
  Scanner a=new Scanner(System.in);{
	  int b=a.nextInt();
	  System.out.println(b+"은 인류의 위대한 발견입니다");
  }
}
