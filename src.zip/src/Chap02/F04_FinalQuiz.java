package Chap02;

import java.util.Scanner;

public class F04_FinalQuiz {
  public static void main(String[] args) {
	Scanner a= new Scanner(System.in);
	int b= a.nextInt();
	System.out.println(b);
}
}
