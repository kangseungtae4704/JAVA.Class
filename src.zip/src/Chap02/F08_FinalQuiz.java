package Chap02;

import java.util.Scanner;

public class F08_FinalQuiz {
  public static void main(String[] args) {
	Scanner a= new Scanner(System.in); // 키보드 입력 변수(객체,묶음)
	{
	  double b=a.nextDouble();  // 실수 1개 입력받기
		System.out.printf("%.2f",b);
	}
}
}
