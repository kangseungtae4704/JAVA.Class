package Chap02;

public class F03_FinalQuiz {
	public static void main(String[] args) {
		int a=20;
		int b=10;
		System.out.println(a+b);
		System.out.println(a-b);
	}
}
