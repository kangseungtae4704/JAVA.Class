package chap05.Section02;
/**
 * 
 * @author user
 * 깊은복사: 권장방식, 반복문사용해서 값넣기
 * int[] o ={1,2};
 * int[] n = new int[2]; 
 * n[0]=10;
 * 스택방                 힙방
 * ---------------------------------------
 * 이름 값                방번호  값 
 *  O  0                  0    1 
 *                        1    2
 *  n  2                  2    10
 *                        3    2
 */
public class S3_DeepCopy {
 public static void main(String[] args) {
	int[] o= {1,2}; //원본(2개)
	int[] n= new int[2]; // 방예약 2개
	System.out.println(o[0]);

//	깊은복사: 반복문 이용 , 원본 훼손 없음
	for (int i = 0; i < 2; i++) {
		n[i]=o[i];
	}
	n[0] = 10; // 수정 1->10(복사본)
	System.out.println(n[0]); //복사본
	System.out.println(o[0]); // 원본 
}
}
