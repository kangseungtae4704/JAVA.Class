package chap05.Section02;

public class S1_for2 {
 public static void main(String[] args) {
	int[] a= {1,2,3,4,5};
//	TODO: 사용법) for(int 변수 : 배열) {} 
//	            변수: 배열의 값이 차례대로 저장됨
//	            반복: 자동으로 배열의 끝까지 반복함
	for (int i : a) {
//		1) i=1
//		2) i=2
//		.....
//		5) i=? (없음) : 반복문 중단 
		System.out.println(i);
		
	}
}
}
