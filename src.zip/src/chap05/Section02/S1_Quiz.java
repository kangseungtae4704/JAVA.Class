package chap05.Section02;

public class S1_Quiz {
public static void main(String[] args) {
	int[] a = {1,2,3,4,5};
	for (int i : a) {
		System.out.println(i);
	}
}
}
