package chap05.Section02;
/**
 * 
 * @author user
 * 얇은복사(shallow Copy): x(사용하지 말자)
 * 사유: 얇은복사본을 수정해버리면 원본까지 수정되버림..
 *  복사: 원본의 값을 그대로 따로 만드는 것 
 */
public class S2_shallwCopy {
   public static void main(String[] args) {
	   int[] o = {1,2}; // 원본배열 
	   System.out.println(o[0]);
	   
	   int[] n=o; // 복사본 배열 (얇은 배열)
	   System.out.println(n[0]);
	   n[0]=10; // 0 -> 10 값 수정(복사본) 
	   System.out.println(n[0]); //복사본
	   System.out.println(n[0]); //원본(수정되면안됨)
}
}
 