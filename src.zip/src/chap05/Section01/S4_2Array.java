package chap05.Section01;

public class S4_2Array {
 public static void main(String[] args) {
//	TODO: 배열 -> 방번호(인덱스번호): 0 ~ 시작 
	 int[][] a= {{1,2},{3,4}};
//	 a[]: 바깥쪽배열: 1, 3[]: 안쪽배열: 2,4
	 System.out.println(a[1][0]);
}
}
