package chap05.Section01;

public class S3_Quiz {
 public static void main(String[] args) {
	double[] a= new double[3];
	a[0]=0.1;
	a[1]=0.2;
	a[2]=0.3;
	System.out.println(a[2]);
}
}
