package chap05.Section01;

public class S1_Quiz {
  public static void main(String[] args) {
	String a="장길산";
	String b= new String("장길산");
//   TODO: 글자비교) .equals
	if(a.equals(b)) {
		System.out.println("같음");
	}
	else {System.out.println("다름");}
  }
}