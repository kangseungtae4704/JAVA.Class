package chap05.Section01;
/**
 * 
 * @author user
 * 배열에 대해 알아봅시다
 * 배열: 여러가지 값을 저장하는 공간, 같은 이름으로 사용할 수 있음
 * 변수: 1가지 값을 저장하는 공간
 * 변수의 단점: 많이 사용 할수록 이름짓기가 너무 힘듬
 */
public class S2_Array {
     public static void main(String[] args) {
//    	사용법: int[] 변수={값1,값2....};
//    	사용법2: System.out.println(변수[방번호]);
//    	참고) 방번호(인덱스번호): 0번부터 시작 
		int[] a= {1,2,3};
		System.out.println(a[0]);
		}
}
