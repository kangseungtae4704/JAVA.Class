/**
 * 
 */
package chap05.Section01;

/**
 * @author user
 * 배열을 만드는 2번쨰 방법
 */
public class S3_Array {
public static void main(String[] args) {
//	double[] a = {0.1, 0.2, 0.3};
	double[] a= new double[3];// 힙방에 방예약 3개
	a[0]=0.1;
	a[1]=0.2;
	a[2]=0.3;
	System.out.println(a[0]);
}
}
