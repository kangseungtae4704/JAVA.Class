package chap05.Section01;

public class S5_QUiZ {
 public static void main(String[] args) {
	 int[][] a= new int[2][2]; 
		a[0][0]=1;
		a[0][1]=2;
		a[1][0]=3;
		a[1][1]=4;
		System.out.println(a[1][0]);
}
}
