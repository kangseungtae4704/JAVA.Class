package chap05.Section01;
/**
 * 
 * @author user
 * 배열의 값을 모두 더하기(누적합 알고리즘): sum=sum+누적시킬값;(반복문 안)
 * 
 */
public class S7_PrefixSum {
 public static void main(String[] args) {
	int[] a= {1,2,3,4,5}; // 학점배열 
	int sum=0;
	for (int i = 0; i < a.length; i++) {
		sum=sum+a[i];//0~4방까지 (i=0~4)
	
	}
	System.out.println(sum);
}
}
