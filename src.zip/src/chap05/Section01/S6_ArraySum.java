/**
 * 
 */
package chap05.Section01;

/**
 * @author user
 * 배열을 반복문을 이용해서 표시해보기
 */
public class S6_ArraySum {
 public static void main(String[] args) {
	int[] a= {1,2,3};
//	배열 개수변수 사용법: 배열변수. length
//	사용법: a[변수]
//	for (int i = 0; i < 3; i++) {
	for (int i=0; i<a.length; i++)
		System.out.println(a[i]);
	}
}

