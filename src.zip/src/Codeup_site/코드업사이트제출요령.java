/**
 * 
 */
/**
 * @author user
 * 사이트주소:https://codeup.kr/index.php
 * 기초100문제 -> C언어
 * 문제사이트:https://codeup.kr/problemsetsol.php?psid=23
 * 문제 제출=> Language: 자바로제출
 */
package Codeup_site;