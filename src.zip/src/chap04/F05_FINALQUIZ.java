package chap04;

import java.util.Scanner;

public class F05_FINALQUIZ {
  public static void main(String[] args) {
	Scanner a=new Scanner(System.in);
	int b=a.nextInt();
	if(b==1) {System.out.println(1);}
	else if(b==2) {System.out.println(2);}
	else if(b==3) {System.out.println(3);}
}
}
