package chap04;

import java.util.Scanner;

public class F09_FINALQUIZ {
 public static void main(String[] args) {
	Scanner a = new Scanner(System.in);
	int b=a.nextInt(); // 5입력 
	
	for (int i = 5; i > 0; i--) {
		System.out.println(i);
	}
}
}
