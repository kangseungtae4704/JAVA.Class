package chap04;

import java.util.Scanner;

public class F06_FINALQUIZ {
 public static void main(String[] args) {
	Scanner a=new Scanner(System.in); 
	String b=a.next();
	for (int i = 0; i < 5; i++) {
		System.out.println(b);
		
	}
	}
	
}

