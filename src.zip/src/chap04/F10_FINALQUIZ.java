package chap04;

import java.util.Scanner;

public class F10_FINALQUIZ {
 public static void main(String[] args) {
	Scanner a = new Scanner(System.in);
	int b=a.nextInt();
	for (int i = 1; i < 10; i++) {
     if(i%2==0){
		System.out.println(i);	
     
	}
}
 }
}
