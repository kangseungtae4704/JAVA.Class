package chap04;

import java.util.Scanner;

public class F07_FINALQUIZ {
  public static void main(String[] args) {
	Scanner a=new Scanner(System.in);
	int b=a.nextInt();
	for (int i = 0; i < b; i++) {
		System.out.println("Hello");
		
	}
}
}
