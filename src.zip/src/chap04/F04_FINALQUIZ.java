package chap04;

import java.util.Scanner;

public class F04_FINALQUIZ {
 public static void main(String[] args) {
	Scanner a=new Scanner(System.in);
	String b=a.next();
	String c=a.next();
	
	if(b.equals("Hello") && c.equals("World"))
	{System.out.println("yes");}
	else {System.out.println("no");
}
}
}