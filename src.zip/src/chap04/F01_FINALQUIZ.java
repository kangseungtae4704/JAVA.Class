package chap04;

import java.util.Scanner;

/**
 * 
 * @author user
 * 힌트) 짝수 ==2의 배수: 값%2==0
 */
public class F01_FINALQUIZ {
 public static void main(String[] args) {
//	객체(묶음 변수): Scanner - 키보드 입력에 관련된 변수, 함수를 가지고 있는 객체
//	사용법) Scanner 변수 => 저장이 안된 상태(이름만 정해둠)
//	 1) new: 들어갈 방을 예약 
//	 2) Scanner(): 방에 들어가게 만들어 줍니다.
//	 정수: int 변수 => 저장공간: 변수 값(저장)
	 Scanner a= new Scanner(System.in);
	 int b=a.nextInt(); // 정수 1개 입력받는 함수
	 
	 if(b%2==0) {System.out.println("even");
	 }else {System.out.println("odd");
}
}
}