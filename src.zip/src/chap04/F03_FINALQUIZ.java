package chap04;

import java.util.Scanner;
public class F03_FINALQUIZ {
 public static void main(String[] args) {
	Scanner a =  new Scanner(System.in);
			String b=a.next();
//			==(등호) 숫자비요 글자: equals()
			if(b.equals("Hello")) {
				System.out.println("World");
			}
}
}
