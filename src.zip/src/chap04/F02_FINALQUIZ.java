package chap04;

import java.util.Scanner;
/**
 * 
 * @author user
 * 정수를 입력 받아 3의 배수이면 yes, 아니면 no라고 표시
 * 
 * 값%3==0 되면 3ㅡ이배수 (어떤 값을 3으로 나누었는데 나머지가 0)
 */
public class F02_FINALQUIZ {
   public static void main(String[] args) {
	   Scanner a= new Scanner(System.in); // 키보드 입력 객체(묶음 변수)
	   { int b=a.nextInt(2); // 정수 1개 입력(2)
	   if(b%3==0) {System.out.println("yes");
	   } else {System.out.println("no");
	   }
	   }
   }}

	   