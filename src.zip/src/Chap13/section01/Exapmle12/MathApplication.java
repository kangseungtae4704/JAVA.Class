/**
 * 
 */
package Chap13.section01.Exapmle12;

/**
 * @author user
 * 수학함수들: 최대값, 최소값, 절대값(음수->양수), 반올림/올림/내림
 */
public class MathApplication {
 public static void main(String[] args) {
	int a=5; 
	int b=10;
//	TODO: 최대값 Math.max(변수1, 변수2):최대값
	System.out.println(Math.max(a, b));
//	TODO: 최소값 Math.min(변수1, 변수2):최소값
	System.out.println(Math.min(a, b));
//	TODO: 절대값 Math.abs(변수)
	int c=-1;
	System.out.println(Math.abs(c));
}
}
