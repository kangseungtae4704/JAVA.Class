package Chap13.section01.Exapmle12;
/**
 * 
 * @author user
 * 수학함수들(Math): 반올림/올림/내림, 1째자리만 됨
 */
public class Math2Application {
 public static void main(String[] args) {
	double a=5.3;
//	TODO: Math.round(변수): 반올림(1쨰자리만)
	System.out.println(Math.round(a)); // 결과:정수
//	TODO: Math.floor(변수): 내림(1쨰자리만)
	System.out.println(Math.floor(a)); //결과: 실수
//  TODO: 올림 Math.ceil(변수)
	System.out.println(Math.ceil(a)); //결과: 실수
}
}
