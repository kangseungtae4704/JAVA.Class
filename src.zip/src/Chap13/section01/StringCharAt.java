package Chap13.section01;

public class StringCharAt {
 public static void main(String[] args) {
	String a = "123456-1234567"; // 주민번호
//	TODO: 사용법:글자.chatAt(방번호) ->0부터시작		
	System.out.println(a.charAt(7));
} 
}
