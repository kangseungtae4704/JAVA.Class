package Chap13.section01.Example08;

public class Quiz {
   public static void main(String[] args) {
	String a= "자바 프로그램. 자바 API";
	String b= a.replace("자바", "Python");
	System.out.println(b);
	
}
}
