package Chap13.section01.Example06;

public class S2_Quiz {
 public static void main(String[] args) {
	String a="자바 프로그램";
	System.out.println(a.indexOf("자바"));
}
}
