package Chap13.section01.Example06;
/**
 * 
 * @author user
 * indexof() 함수: 글자의 위치를 알려주는 함수 
 */
public class IndexOfApplication {
	public static void main(String[] args) {
//		배열: 0부터 시작, 글자: 0부터 시작
		String a="자바 프로그램";
//		프로그램 글자의 인덱스(방번호) 위치는 얼마인가요?
//		사용법: 글자.indexof("부분글자")
		System.out.println(a.indexOf("프로그램"));
	}
}
