package Chap13.section01.Example09;

public class Quiz {
   public static void main(String[] args) {
	   String a="123456-1234567";
	   String b=a.substring(7,14);
	   System.out.println(b);
}
}
