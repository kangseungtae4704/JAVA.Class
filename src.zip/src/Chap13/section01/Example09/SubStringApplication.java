/**
 * 
 */
package Chap13.section01.Example09;

/**
 * @author user
 * substring() : 글자에서 일부분을 잘라내서 보여주는 함수
 */
public class SubStringApplication {
 public static void main(String[] args) {
	String a="123456-1234567"; // 주민번호
//	TODO: a.substring(시작방번호, 끝방번호+1);
	String b=a.substring(0, 6);
	System.out.println(b);
}
}
