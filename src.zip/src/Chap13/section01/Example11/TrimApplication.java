package Chap13.section01.Example11;
/**
 * 
 * @author user
 *trim(): 양쪽의 공백을 없애주는 함수, 단, 중간공백은 안없애줌
 */
public class TrimApplication {
  public static void main(String[] args) {
	String a=" 02";
	String  b=" 0  2";
	String c="  02  ";
//			TODO: 사용법) 변수.trim());
	System.out.println(a.trim());
	System.out.println(b.trim());
	System.out.println(c.trim());
}
}
