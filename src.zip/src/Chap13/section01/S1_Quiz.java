package Chap13.section01;

public class S1_Quiz {
  public static void main(String[] args) {
	String a="123456-1234567";
	System.out.println(a.charAt(4));
}
}
