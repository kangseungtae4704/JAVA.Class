package Chap13.section01.Example07;

/**
 * 
 * @author user
 * length() : 글자의 개수를 나타내는 함수
 */
public class LenghtApplication {
  public static void main(String[] args) {
	  String a = "123456"; // 6개 
	  System.out.println(a.length());
} 
  
}
