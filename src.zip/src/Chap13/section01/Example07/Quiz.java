package Chap13.section01.Example07;

public class Quiz {
 public static void main(String[] args) {
	String a="1234567"; //7
//	a.length => 숫자의갯수
	System.out.println(a.length());
}
}
