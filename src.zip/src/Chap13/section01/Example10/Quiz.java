package Chap13.section01.Example10;

import java.util.Arrays;

public class Quiz {
 public static void main(String[] args) {
	String a = "010-123-1234";
	String[] b=a.split("-");
	System.out.println(b[0]);
	System.out.println(b[1]);
	System.out.println(b[2]);
	System.out.println(Arrays.toString(b));
}
}
