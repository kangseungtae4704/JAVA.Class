package Chap13.section01.Example10;

import java.util.Arrays;

public class SplitApplication {

	 public static void main(String[] args) {
		String a="123456-1234567";
//		TODO: 사용법) String[] 변수=a.split("자를문자");
		String[] b= a.split("-");
//	("123456","1234567"):배열이되면 이렇게잘려있음
		System.out.println(b[0]);
		System.out.println(b[1]);
		//참고) 배열을 통째로 화면에 표시해주는 함수;["",""]
		System.out.println(Arrays.toString(b));
	}
}
