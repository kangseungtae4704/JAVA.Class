package chap06.Section02.Example03.quiz03;

public class taxi {
 String model;
 int maxSpeed;
public taxi() {
	super();
}
public taxi(String model) {
	super();
	this.model = model;
}
public taxi(int maxSpeed) {
	super();
	this.maxSpeed = maxSpeed;
}
public taxi(String model, int maxSpeed) {
	super();
	this.model = model;
	this.maxSpeed = maxSpeed;
} 
 
 
}
