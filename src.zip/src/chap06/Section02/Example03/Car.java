package chap06.Section02.Example03;

public class Car {
 String company; // 회사
 int speed; // 차속도
public Car() {
	super();
}
public Car(String company) {
	super();
	this.company = company;
}
public Car(int speed) {
	super();
	this.speed = speed;
}
public Car(String company, int speed) {
	super();
	this.company = company;
	this.speed = speed;
}

}
