package chap06.Section02;
/**
 * 
 * @author user
 * 클래스 3요소: 1) 필드 2) 생성자 함수
 */
public class Car {
//  필드 
	String color;
//	생성자함수: 객체를 힙방에 직접 만들어주는 함수
//	생성자함수1(생략가능): 이클립스가 만듬:  
//	오른쪽 - Source -Generate Constructor using Fields
//  TODO: 만약 생성자 함수를 1개도 안만들면 컴퓨터가 만들어줌 
public Car() {
	super();} // 상속 기능이 되야 의미가 있음(무시, 효과가 없음)

//	생성자함수2: 이클립스가 만듬;
//  함수: 토스트기: 식방을 넣으면 구운빵으로 만들어줌 
//  구운빵=car(식빵)
//  Car("검정")=> color ="검정"
//	String 변수="검정"
//  Car(String color); => Car("검정")
public Car(String color) {
	super(); // 상속 기능이 되야 의미가 있음(무시, 효과가 없음)
//	TODO: this 예약어 : 클래스(객체) 자기자신을 의미
	this.color = color;
}
}



