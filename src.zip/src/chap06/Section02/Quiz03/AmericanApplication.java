package chap06.Section02.Quiz03;

public class AmericanApplication {
 
  public static void main(String[] args) {
	  American american = new American("James","123");
	  System.out.println(american.name);
	  System.out.println(american.num);
	  
	  American american2 = new American("Bond", "234");
	  System.out.println(american2.name);
	  System.out.println(american2.num);
	 	  
}
  
}
