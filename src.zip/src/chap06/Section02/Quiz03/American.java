package chap06.Section02.Quiz03;

public class American {
	 String name;
	   String num;
	public American(String name, String num) {
		super();
		this.name = name;
		this.num = num;
	}
	   
	   
}
