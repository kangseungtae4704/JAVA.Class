package chap06.Section02;

public class CarApplication {
 public static void main(String[] args) {
//	객체만들기 사용버) 클래스명 변수=new 생성자함수();
//	TODO: 생성자함수를 이용한 필드 값넣기(추천)
	 Car car = new Car("검정"); //필드에 값 넣기
	 System.out.println(car.color);
}
}
