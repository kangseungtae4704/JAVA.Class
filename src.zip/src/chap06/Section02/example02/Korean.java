package chap06.Section02.example02;

public class Korean {
 String name;
 String ssn; // 주민번호

 
 // 생성자: 1)변수 없는 것 2) 변수 1개 있는 것
//        3)변수 2개 있는 것 
// super는 나중에씀 지금은 무시
 // 변수없는 것
 public Korean() {
		super();
	}
// 변수 1개  (name)
// 참고사항: 변수를 1개, 1개 만들떄는 규칙이달라야함
// ex) String-String (X) String-int (O)
	public Korean(String name) {
		super();
		this.name = name;
	}
//	변수 2개 (name, ssn)
	public Korean(String name, String ssn) {
		super();
		this.name = name;
		this.ssn = ssn;
	}


}
