package chap06.Section02.Quiz2;

public class Taxi {
 String company; // 값: null

public Taxi(String company) {
	super(); // 무시 (아무 효과가 없음)
	this.company = company;
	
//// 기본 생성자	
//	
//}
//public Taxi() {
//	super();
//}
//// 변수사용하는 생성자: - 개발자 선호
//public Taxi(String company) {
//	super();
//	this.company = company;
}
}

 

