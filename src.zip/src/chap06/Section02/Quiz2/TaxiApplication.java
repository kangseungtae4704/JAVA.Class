package chap06.Section02.Quiz2;

public class TaxiApplication {
	public static void main(String[] args) {
		Taxi taxi = new Taxi("기아");
		System.out.println(taxi.company);
	}
	

}
