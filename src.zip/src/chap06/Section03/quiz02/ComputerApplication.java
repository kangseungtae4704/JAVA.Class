package chap06.Section03.quiz02;

import java.util.Scanner;

public class ComputerApplication {
  public static void main(String[] args) {
	Computer computer = new Computer();
	computer.poweroff();
	System.out.println(computer.minus(6, 5));
	
	
}
}
