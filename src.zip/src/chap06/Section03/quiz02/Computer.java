package chap06.Section03.quiz02;

public class Computer {
  void poweroff() {
	  System.out.println("전원끄기");
  }
  int minus(int x, int y){
	  return x-y;
  }
  void comprint(int x, int y) {
	  poweroff();
	  System.out.println(minus(x,y));
	  
  }
}
