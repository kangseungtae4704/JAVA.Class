package chap06.Section03.example04;
/**
 * 
 * @author user
 * 실행 클래스: main
 */
public class CarApplication {
  public static void main(String[] args) {
//	클래스 만들기 : 클래스 변수=new 생성자 함수 
	  Car car = new Car();
	  car.myprint("현대");
	  car.myprint(20);
	  car.myprint("기아", 30);
}
}
