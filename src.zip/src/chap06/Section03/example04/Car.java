package chap06.Section03.example04;
/**
 * 
 * @author user
 * 오버로딩(함수이름 동일하게 사용하기: 조건에 따라)
 */
public class Car {
//  1) 함수 사용법2: void 함수명(매개변수){}
	void myprint(String brand) {
//		기능코딩
		System.out.println(brand);
	}
//	2)
		void myprint(int speed) {
	System.out.println(speed);	}	
	
//  3) 
   void myprint(String brand , int speed) {
     System.out.println(brand);
     System.out.println(speed);  
   }
   }