package chap06.Section03.example02;

public class CalculatorApplication {
// 클래스 만들기 사용법: 클래스 변수 = new 생성자함수();
	
    public static void main(String[] args) {
    	Calculator calculator = new Calculator();
    	calculator.poweron();
    	System.out.println(calculator.plus(3, 3));
	}
}
