package chap06.Section03.example02;

public class Calculator {
// 1) void 함수(){} 
void poweron() {
	System.out.println("전원켜기");
}
// 2) 6,5 넣으면 덧셈 plus 


// 3) 자료형 함수(매개변수){}
 int plus(int x , int y){
	 return x+y;
 }


void myprint(int x, int y){
    poweron(); // 전원켜기(바로사용, 클래스안만듬)
    System.out.println(plus(x,y));
}
}
