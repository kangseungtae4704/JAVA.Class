package chap06.Section03.example01;

public class CalculatorApplication {
// 실행클래스: main () => 결과볼려고 만듬
	public static void main(String[] args) {
		Calculator calculator= new Calculator();
		calculator.poweron(); // 전원 켜기 화면표시
		
		calculator.minus(5);
		
		 // 결과가 값으로 나옴 1) 변수 저장 2) 화면 표시
		System.out.println(calculator.plus(2, 1));
	}
}
