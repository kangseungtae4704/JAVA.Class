package chap06.Section03.example01.quiz01;
// 2개 1) poweroff 
public class Computer {
  void poweroff(){
	  System.out.println("전원끄기");
  }
  int minus(int x, int y) {
	  return x-y;
  }
}
