package chap06.Section03.example01.quiz01;

public class ComputerApplication {
 public static void main(String[] args) {
	Computer computer = new Computer();
	computer.poweroff();
	
	System.out.println(computer.minus(6, 5));
}
}
