package chap06.Section03.quiz03;

public class Taxi {
 int Speed;

public int getSpeed() {
	return Speed;
}

public void setSpeed(int speed) {
	Speed = speed;
} 
 
 
}
