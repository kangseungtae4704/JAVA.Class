package chap06.Section03.quiz03;



public class TaxiApplication {
	public static void main(String[] args) {
		 Taxi taxi = new Taxi();
		 taxi.setSpeed(20);
		 System.out.println(taxi.getSpeed());
	}

}
