package chap06.Section03.example03;

public class CarApplication {
 public static void main(String[] args) {
	 Car car=new Car();
	 car.setSpeed(1); // 이 방법 좋지 않 습니다.
//	 TODO: 실무에서는 필드보다 함수를 이용하는 방법을 선호하빈다.(정보보호에 안전)
	 System.out.println(car.getSpeed()); // 이 방법이 좋습니다.
	 
//	 TODO: 왜? 필드에 바로 값을 사용하면 안되나..
//	 car.speed=-1; // 상식적으로 차의 속도가 마이너스가 될수 있나?
//	 => 프로그램자체에서 값을 수정해버리면 개발자가 수정할 방법이 없음...
	 car.setSpeed(-1); // 필드값 수정 함수(세터) 
     System.out.println(car.getSpeed());
}
 
}
