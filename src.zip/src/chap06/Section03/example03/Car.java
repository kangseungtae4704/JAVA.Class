package chap06.Section03.example03;

public class Car {
// 클래스 3요소 1) 필드 2) 생성자 3) 메소드(함수)
	
//	메소드 만들기: Getter() vs Setter()
//	사용법: 오른쪽 클릭 -source- Generate Getter and Setter 선택 
//	목적: Getter함수 목적: 필드의 값을 결과 내보내기 하는 함수 
	
	int speed;

	public int getSpeed() {
		return speed;
	}
//	TODO: Setter함수 목적: 생성자랑 비슷(필드의 
	public void setSpeed(int speed) {
//		코딩 개선: 음수가 나오면 무시
		if(speed>0){this.speed = speed; // 양수일때만 값 넣기}
		 // 생성자랑 비슷(필드의 값 넣기)
	} 
	}
}
