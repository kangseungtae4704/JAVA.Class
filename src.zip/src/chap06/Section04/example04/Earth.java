package chap06.Section04.example04;
/**
 * 
 * @author user
 * 전역 상수 만들기 
 */
public class Earth {
//	전역 상수 사용법: static final 자료형 변수="값";
//	전역 뜻: 1개만 만들고 공유하는 변수 2) 수정할 수 없음 
  static final double EARTH_R=6400; // 지구 반지름
}
