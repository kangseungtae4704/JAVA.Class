package chap06.Section04.example04;
/**
 * 
 * @author user
 * 실행클래스: main 
 */
public class EarthApplication {
 public static void main(String[] args) {
//	전역 상수 사용법: 클래스명.상수 
	System.out.println(Earth.EARTH_R);
}
}
