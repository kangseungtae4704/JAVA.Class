package chap06.Section04.quiz;

public class Computer {
 public static int minus (int x, int y) {
	 return x-y;	
}
}
