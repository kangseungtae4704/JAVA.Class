package chap06.Section04.quiz;

public class ComputerApplication {
   public static void main(String[] args) {
	System.out.println(Computer.minus(10,5));
	
	int result=Computer.minus(10, 5);
	System.out.println(result);
   }
}
