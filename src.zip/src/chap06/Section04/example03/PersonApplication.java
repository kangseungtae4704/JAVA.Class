package chap06.Section04.example03;

public class PersonApplication {
 public static void main(String[] args) {
	Person person=new Person("홍길동");
	
	System.out.println(person.name);
	System.out.println(person.nation);
	
//	person.nation="A" // 에러) 상수라서 수정안됨
}
}
