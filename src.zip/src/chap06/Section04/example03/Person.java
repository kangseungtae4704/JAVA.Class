package chap06.Section04.example03;
/**
 * 
 * @author user
 * 상수 만들기
 * 변수: 1개 값을 저장하는 곳, 값을 수정할 수 있음  
 * 상수 뜻: 1개 값을 저장하는 곳, 값을 수정 할 수 없음 
 *      주의) 만들고 나서 바로 값을 넣어야함(아니면 error발생)
 */
public class Person {
// 클래스 3요소: 1) 필드 2) 생성자 함수 3) 메소드 
// 필드(변수)
// 상수 사용법: final  자료형 상수 = "값";
   final String nation="Korea"; 
   
   final String name;
//   참고) 생성자로 값 넣기(비추천)

public Person(String name) {
	super();
	this.name = name;
}
   
}
