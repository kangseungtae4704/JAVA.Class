package chap06.Section04.quiz04;

public class MoonApplication {
   public static void main(String[] args) {
	System.out.println(Moon.Moon_R);
}

}
