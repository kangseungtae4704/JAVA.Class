package chap06.Section04.quiz04;

public class Moon {
 static final double Moon_R=3000;
}
