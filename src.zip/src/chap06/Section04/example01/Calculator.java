package chap06.Section04.example01;
/**
 * 
 * @author user
 * 계산기 클래스
 */
public class Calculator {
//	클래스 3요소: 1) 필드 2) 생성자함수 3) 메소드
//  필드 static => 전체함수에 공유
//	전역변수 만들기 사용법: Static 자료형 = 변수(값);
//	효과: 모든 클래스가 변수를 공유할 수 있음 
  static double pi = 3.14; 
//  전역메소드 만들기 사용법: static 자료형 함수명(매개변수){실행문;}
//  함수 자동완성: pu
   public static int plus(int x, int y){
	   return x+y;
	
}
	
}
