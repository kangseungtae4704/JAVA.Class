package chap06.Section04.example01;

public class CalculatorApplication {
   public static void main(String[] args) {
//	전역변수 사용법 2: 클래스명.전역변수
//	참고) 공식: 원의넓이: 반지름 * 반지름 *3.14
	double result = 10*10*Calculator.pi;
	System.out.println(result);
	
//	전역 메소드 사용법2: 클래스명.전역메소드
	System.out.println(Calculator.plus(10, 5));
}
}
