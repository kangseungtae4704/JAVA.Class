package chap06.Section04.example02;
/*
 * 실행클래스: main 
 * 전역변수 => 사용법 1) static 자료형 변수;
 * 전역변수 => 사용법 2) 클래스명.전역변수 
 * 
 *  참고) 전역메소드 안에서 일반변수를 사용할때 주의 점 
 *        1) 전역메소드는 일반 변수를 바로 사용 못함 
 *         2) 클래스만들기로 사용: 클래스 변수=new 생성자함수();		
 */
public class CarApplication {
     int speed; // 일반변수(필드)
     
     public void name(){speed=1;} // 일반매소드
     
     public static void main(String[] arrgs) {
//		TODO: 전역메소드는 일반 변수를 바로 사용 못함
//    	      클래스만들기로 사용: 클래스 변수 = new 생성자함수();
    	 CarApplication car=new CarApplication();
    	 car.speed=2;
    	 
	}
}
