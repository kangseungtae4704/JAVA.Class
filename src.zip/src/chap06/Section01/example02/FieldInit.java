package chap06.Section01.example02;
/**
 * 
 * @author user
 * 클래스 3요소: 1) 필드: (맴버변수,인스턴변수): 변수, 클래스의 안의 변수
 */
public class FieldInit {
// 필드
// 정수: 4가지
   byte byteVal;
   short shortVal;
   int intVal;
   long longVal;
   
// 실수: 2가지 
   float floatVal;
   double doubleVal;
   
// 참/거짓
   boolean booleanVal;
   
//	글자/배열
	String stringVal;
    int[] arrayVal;
    
//  char: 글자 1개 
    char charVal;
}




