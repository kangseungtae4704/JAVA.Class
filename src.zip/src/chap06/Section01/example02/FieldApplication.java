package chap06.Section01.example02;
/**
 * 
 * @author user
 * 실행클래스: 1개만 있으면 됨 
 */
public class FieldApplication {
	public static void main(String[] args) {
		FieldInit fieldInit = new FieldInit();
//		정수 초기값(컴퓨터가 넣어둠): 0
		System.out.println(fieldInit.byteVal);
		System.out.println(fieldInit.intVal);
		System.out.println(fieldInit.longVal);
		System.out.println(fieldInit.shortVal);
//		실수 초기값: 0.0
		System.out.println(fieldInit.floatVal);
		System.out.println(fieldInit.doubleVal);
//	    참거짓: 생략하면 false가 나옴 
		System.out.println(fieldInit.booleanVal);
		
//		글자/배열: null(아무것도 없을을 뜻하는예약어
		System.out.println(fieldInit.stringVal);
		System.out.println(fieldInit.arrayVal);
//		글자 1개 
		System.out.println(fieldInit.charVal);
	}
  
  
}
