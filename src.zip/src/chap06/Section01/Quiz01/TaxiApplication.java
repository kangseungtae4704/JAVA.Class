package chap06.Section01.Quiz01;

public class TaxiApplication {
  public static void main(String[] args) {
	Taxi taxi = new Taxi();
	System.out.println(taxi.Company);
	System.out.println(taxi.maxSped);
	
	taxi.maxSped="60";
	System.out.println(taxi.maxSped);
}
}
	