package chap06.Section01.Quiz01;

public class Taxi {
 String Company = "기아자동차";
 String maxSped ="50";
}
