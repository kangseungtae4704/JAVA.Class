/**
 * 
 */
package chap06.Section01.example01;

/**
 * @author user
 * 클래스 3요소: 1) 필드(변수)
 * 객체만들기 main함수가 미포함
 */
public class Car {
   String company = "현대자동차";
   int maxSpeed=30;
}
