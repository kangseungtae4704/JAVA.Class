package chap06.Section01.example01;

/**
 * @author user
 * 실행 클래스 main 함수가 포함
 */
public class CarApplication {
   public static void main(String[] args) {
	   Car car=new Car();
//	   자동완성: ctrl+space 
//	   객체 사용목적: 변수만 사용하면 나중에 너무 많은 변수로 인해 스트레스 받음
//	           TODO: (1) 사용법: Car 변수=new Car();
//	                 (2) 사용법: 변수.필드
//	   1) Car 변수; -> Car 객체 이름 정하기
//	   2) new ->힙방에 방예약(2개)
//	   3) Car() -> 실질적으로 힙방에값을 넣어두는 함수(생성자함수)
	   System.out.println(car.company);
	   System.out.println(car.maxSpeed);
//	   필드(변수) 값 수정: 30->60 
	   car.maxSpeed=60;
	   System.out.println(car.maxSpeed);
}
}
