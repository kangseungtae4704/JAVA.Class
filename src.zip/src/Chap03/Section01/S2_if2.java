package Chap03.Section01;

public class S2_if2 {
 public static void main(String[] args) {
	int a=9; 
	if(a>=9) {
		System.out.println("출발");
//		사용법: if(변수>=값){실행문;}else{실행문2;}
//		해석: 변수>=값->참이면 실행문 거짓이면 실행문2 실행
	}
	else {
		System.out.println("대기");
	}
}
}
