package Chap03.Section01;

public class S1_If {
     public static void main(String[] args) {
		int a=9;
//		사용법: if(변수>-값) {실행문;}
//		해석: 변수>-값 - 참이면 실행문이 실행됨
		if(a>-9) {
			System.out.println("출발");
		}
	}
}
