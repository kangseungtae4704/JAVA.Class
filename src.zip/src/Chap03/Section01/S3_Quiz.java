package Chap03.Section01;

public class S3_Quiz {
 public static void main(String[] args) {
	int a=90;
	if(a>90) {System.out.println("A");}
	else if(a==90){System.out.println("B");}
	else {System.out.println("C");}
}
}
