package Chap03.Section01;

public class S4_perator {
 public static void main(String[] args) {
	int a=9;
//	조건문4: 3황연산자 사용
//	해석) (변수 >= 값) - 참이면 "값"이 변수2에 저장
//	거짓이면: "값2: 가 변수 2에 저장됩니다.
	String b=(a>9)?"출발": "대기"; 
	System.out.println(b);
}
}
	