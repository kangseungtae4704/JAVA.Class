package Chap03.Section01;

public class S2_Quiz {
    public static void main(String[] args) {
		int a= 90;
		if(a>=90) {System.out.println("A");}
		else {System.out.println("C");}
	}
}
