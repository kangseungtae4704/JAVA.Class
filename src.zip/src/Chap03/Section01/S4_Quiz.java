package Chap03.Section01;

public class S4_Quiz {
 public static void main(String[] args) {
	int a=90;
	String b=(a>=90)? "A" : "C"; 
		System.out.println(b);
}
}
