package Chap03.Section02;

public class S3_Quiz {
 public static void main(String[] args) {
	int i=0;
	while( i < 10 ){
		i++;
		System.out.println("홍길동");
	}
}
}
