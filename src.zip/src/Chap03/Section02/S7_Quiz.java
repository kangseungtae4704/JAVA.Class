package Chap03.Section02;

public class S7_Quiz {
 public static void main(String[] args) {
	for (int i = 1; i <=5; i++) {
		if(i==2) {
		continue;
	}
	System.out.println(i);
}
}
}