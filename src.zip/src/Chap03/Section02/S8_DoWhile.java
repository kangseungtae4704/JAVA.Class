package Chap03.Section02;/**
 * 
 * @author user
 * 참고 : while 반복문: 잘 안씀
 * while vs do~while 차이:
 * 1) while(for): 1) 조건확인: 참 2)실행문 실행
 * 2) do~while: 1)실행문 먼저 실행 2)조건확인: 참 
 */
public class S8_DoWhile {
  public static void main(String[] args) {
//	  system.out.pritln("안녕:);
	  int i = 0;
	  do{
		  System.out.println("안녕");
		  i++;
		  
		
	}
	  while( i < 10);
}
}
