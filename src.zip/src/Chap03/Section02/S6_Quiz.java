package Chap03.Section02;

public class S6_Quiz {
 public static void main(String[] args) {
	int i=10;
	while(true) {
		System.out.println(i);
		i++;
		if(i==20) {
		break;}
	}
}
}
