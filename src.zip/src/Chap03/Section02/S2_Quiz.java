package Chap03.Section02;

public class S2_Quiz {
 public static void main(String[] args) {
	int sum= 0; 
	for (int i = 1; i <= 100; i++) {
		 sum=sum+i;
	}
	System.out.println(sum);
}
}
