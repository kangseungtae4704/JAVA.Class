package Chap03.Section02;

import java.util.Iterator;

public class S1_Quiz {
 public static void main(String[] args) {
	for (int i = 0; i < 10; i++) {
		System.out.println("홍길동");
		
	}
}
}
