package Chap03.Section02;
/**
 * 
 * @author user
 * 구구단: 2단 화면에 표시
 */
public class S4_For3 {
 public static void main(String[] args) {
////	2 X 1 = 2 
//	 System.out.println("2 X 1"+"="+(2*1));
////	2 X 2 = 4
//	 System.out.println("2 X 2"+"="+(2*2));
////	2 X 3 = 6
//	 System.out.println("2 X 3"+"="+(2*3));
	 
	 for(int i =1; i<=9; i++) {
		 System.out.println("2X"+i+"="+(2*i));
	 }
}
}
