package Chap03.Section02;

public class S4_Quiz {
 public static void main(String[] args) {
	for (int i = 1; i <=9 ; i++) {
      System.out.println("3X"+i+"="+(3*i));
		
	}
}
}
