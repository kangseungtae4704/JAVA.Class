package Chap03.Section02;
/**	
 * 
 * @author user
 *
 */
public class S9_ForIf {
 public static void main(String[] args) {
	for (int i = 1; i <= 10; i++) {
//		2의 배수: 2,4,6... : 값을 2로 나눈 나머지가 0{나머지}
//		: 값%2=0
		if(i%2==0) {
	  System.out.println(i);	
	}
}
}
}