package Chap03.Section02;

public class S1_For {
 public static void main(String[] args) {
	 for (int i = 0; i <  20; i++) {
//		 사용법: for (int 변수=최초값; 변수<=반복횟수; 변수++) { 	 	 
//		 해석) 1) i=0, i<20(참), 반복, System.out.println("안녕"); 실행, i++(1증가)
//		      2) i=1, 1<20(참), 반복, System.out.println("안녕"); 실행, i++(1증가)
//		      3) i=2, 2<20(참), 반복, System.out.println("안녕"); 실행, i++(1증가)
//		      ...
//		      21) i=20, 20<20(거짓), 반복 중단{} 빠져나옴, System.out.println("안녕"); 실행, i++(1증가)
		 System.out.println("안녕");	
		 
	}
	 }
}