package Chap03.Section02;

public class S3_While {
 public static void main(String[] args) {
//	사용법: 1) int 변수 = 값;
//	      2) while(변수<반복횟수){실행문; 변수++;}
//	     해석: 변수 < 반복횟수 -> 참이면 실행문 실행, 거짓이면 중단 
//	자동완성: ctrl+space
//	 while (condition) {
	int i = 0;
	 while (i < 20) {
		System.out.println("안녕");
		i++;
	}
}
}
