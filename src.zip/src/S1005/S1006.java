package S1005;

public class S1006 {
   public static void main(String[] args) {
	System.out.println("\"!@#$%^&*()\"");
}
}
