package S1005;

public class S1007 {
 public static void main(String[] args) {
	System.out.println("\"C:\\Download\\hello.cpp\"");
}
}
