package S1005;

public class S1004 {
public static void main(String[] args) {
	System.out.println("'Hello'");
}
}
