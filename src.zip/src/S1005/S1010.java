package S1005;

import java.util.Scanner;

public class S1010 {
	public static void main(String[] args) {
		 Scanner a= new Scanner(System.in);
		 int b=a.nextInt();
		 System.out.println(b);
	}

}

