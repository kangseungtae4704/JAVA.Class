package S1005;

public class S1001 {
 public static void main(String[] args) {
	
	String a="Hello";
	System.out.println(a);

 }
}
