package Chap08.quiz01;
//부모 클래스
public class Table {
  String brand; 
  
  public void poweroff() {
	  System.out.println("전원끄기");
	}
}
