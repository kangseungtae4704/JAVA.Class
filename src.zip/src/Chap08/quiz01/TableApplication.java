package Chap08.quiz01;
// 실행클래스 
public class TableApplication  {
public static void main(String[] args) {
	Ipad ipad = new Ipad("애플"); 
	
	System.out.println(ipad.brand);
	System.out.println(ipad.click);
	ipad.poweroff();
    ipad.turnon();
}
}
