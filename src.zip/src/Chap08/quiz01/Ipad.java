package Chap08.quiz01;
//자식 클래스
public class Ipad extends Table {
  String click;
	public Ipad(String brand) {
		super();
		this.brand=brand;	}
  
	   public void turnon() {
		System.out.println("웹브라우저를 엽니다.");
	}
}
