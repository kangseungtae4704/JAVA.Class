package Chap08.section01.example03;

public class ComputerApplication {
//    클래스 만들기: 클래스 변수=new 생성자함수(); 
	  
	  public static void main(String[] args) {
		  Calculator calculator = new Calculator();
		  System.out.println(calculator.circle(10));
		  
		  Computer computer = new Computer();
		  System.out.println(computer.circle(10)); // 자식쪽 circle 함수
		  
	}
}
