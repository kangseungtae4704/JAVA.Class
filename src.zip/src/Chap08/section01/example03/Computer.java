package Chap08.section01.example03;
/**
 * 
 * @author user
 * 자식클래스
 * 상속을 받았는데 (필드, 생성자, 메소드) , 부모쪽에 메소드의 코딩이 마음에 안들어서 조금 수정하고 싶을 때 사용 
 * (메소드 오버라이딩)
 * 예) 부모에게서 장롱을 1개 받았는데 마음에 안들어서 페인트칠을 조금 하고싶다. 
 */ 
public class Computer extends Calculator {

	@Override
	public double circle(double r) {
		// TODO Auto-generated method stub
		return r*r*Math.PI; // PI(3.141592......, 정밀도가 높은 3.14)
	}
//   메소드 오버라이딩 기능: 템플릿(이클립스)
//	 
	
}
