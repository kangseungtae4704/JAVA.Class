package Chap08.section01.example03;
/**
 * 
 * @author user
 * 부모 클래스 
 */
public class Calculator {
   public double circle(double r) {
	   return r*r*3.14;
}
}
