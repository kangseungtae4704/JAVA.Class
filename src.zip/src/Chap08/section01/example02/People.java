/**
 * 
 */
package Chap08.section01.example02;

/**
 * @author user
 * 부모 클래스
 */
public class People {
//  필드
	String name;
// 생성자
public People(String name) {
	super();
	this.name = name;
} 
	
	

}
