package Chap08.section01.example02;
/**
 * 
 * @author user
 * 실행클래스
 */
public class PeopleApplication {
	public static void main(String[] args) {
		 studnet studnet=new studnet("홍길동", 1);
		 System.out.println(studnet.name);
		 System.out.println(studnet.no);
	}
   
    
}
