package Chap08.section01.example02;
/**
 * 
 * @author user
 * 자식클래스
 * ◼ 필드: int no 
   ◼ 생성자:  
   ◆ 매개변수: String name, int no 
 */
public class studnet extends People {
    int no;
//  생성자
//  TODO 생성자: 상속 받았을 때 주의점 1) 부모쪽에 있는 생성자를 반드시 실행하여야함(에러표시)
	public studnet(String name, int no) {
//  TOOD: super() : 부모 생성자함수를 의미함(모양이 똑같아야함)
		super(name);
		this.no = no;
	}
    
}
