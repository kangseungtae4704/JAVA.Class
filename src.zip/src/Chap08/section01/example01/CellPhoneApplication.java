package Chap08.section01.example01;
/**
 * 
 * @author user
 * 실행클래스 : main
 */
public class CellPhoneApplication {
      public static void main(String[] args) {
		DmbCellPhone dmbCellphone = new DmbCellPhone("자바", 10);
//		자식 클래스 필드 모두 화면 표시 
		System.out.println(dmbCellphone.channel);
		System.out.println(dmbCellphone.model);
		
      dmbCellphone.powerOn();
      dmbCellphone.turnOn();}
}
