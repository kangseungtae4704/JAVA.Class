package Chap08.section01.example01;
/**
 * 
 * @author user
 * 메소드 : "전원켜기" 화면에 표시합니다.
 * 이름
 * :poweron
 * 매개변수:없음
 * return 자료형 void
 */
public class CellPhone {
//  클래스의 3요소: 1) 필드 2) 생성자 함수 3) 메소드
//  필드 
	String model;
//	생성자 생략 
//	메소드 
	public void powerOn() {
		System.out.println("전원켜기");
	}
}
