package Chap08.section01.example01;
/**
 * 
 * @author user
 * 자식 클래스 
 * 필드: int channel 
 * 메소드 : "tv를 수신합니다." 화면에 표시합니다.
 * 이름 : turnOn 
 * 매개변수: 없음 
 * return 자료형: void 
 */
public class DmbCellPhone extends CellPhone {
//      필드 
	int channel; 
	
	public DmbCellPhone(String model,int channel) {
	super();
	this.channel = channel;
	this.model=model;
}

	// 생성자 함수 
	  
	
//	생성자 함수 생략
//	메소드
	public void turnOn() {
		System.out.println("tv를 수신합니다.");
	}

	public DmbCellPhone(int channel) {
		super();
		this.channel = channel;
	}
}
